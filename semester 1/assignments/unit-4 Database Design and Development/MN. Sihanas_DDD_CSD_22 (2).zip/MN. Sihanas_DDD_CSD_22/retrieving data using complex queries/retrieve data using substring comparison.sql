SELECT * FROM Guest
WHERE Name LIKE 'A%';
