SELECT RoomID FROM RoomFacility
UNION
SELECT RoomID FROM Employee;
