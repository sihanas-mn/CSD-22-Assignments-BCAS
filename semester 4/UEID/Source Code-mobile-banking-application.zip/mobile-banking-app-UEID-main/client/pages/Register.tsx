import { Link } from "react-router-dom";

export default function Register() {
  return (
    <div className="min-h-screen bg-white font-inter relative">
      {/* Back button */}
      <Link to="/" className="absolute top-6 left-2 z-20">
        <img
          src="https://api.builder.io/api/v1/image/assets/TEMP/5afa2f28df65147856f2e42952a6ea57e57d3616?width=138"
          alt="Back"
          className="w-[69px] h-[53px]"
        />
      </Link>

      {/* Header */}
      <div className="text-center pt-8 pb-6">
        <h1 className="text-2xl font-semibold text-black">Register</h1>
        <div className="w-full h-px bg-black mt-4"></div>
      </div>

      {/* Main heading */}
      <div className="text-center mb-10 px-7">
        <h2 className="text-[32px] font-semibold text-black leading-normal">
          Let's create an account for you!
        </h2>
      </div>

      {/* Registration form */}
      <div className="px-9 flex flex-col gap-4">
        {/* Full name input */}
        <div className="relative">
          <input
            type="text"
            placeholder="Full name"
            className="w-full h-[63px] border-3 border-bank-primary rounded-[10px] bg-white backdrop-blur-sm px-6 text-xl font-semibold text-[#5E5E5E] placeholder:text-[#5E5E5E] focus:outline-none focus:ring-2 focus:ring-bank-primary"
          />
        </div>

        {/* Username input */}
        <div className="relative">
          <input
            type="text"
            placeholder="username"
            className="w-full h-[63px] border-3 border-bank-primary rounded-[10px] bg-white backdrop-blur-sm px-6 text-xl font-semibold text-[#5E5E5E] placeholder:text-[#5E5E5E] focus:outline-none focus:ring-2 focus:ring-bank-primary"
          />
        </div>

        {/* Email input */}
        <div className="relative">
          <input
            type="email"
            placeholder="Email"
            className="w-full h-[63px] border-3 border-bank-primary rounded-[10px] bg-white backdrop-blur-sm px-6 text-xl font-semibold text-[#5E5E5E] placeholder:text-[#5E5E5E] focus:outline-none focus:ring-2 focus:ring-bank-primary"
          />
        </div>

        {/* Password input */}
        <div className="relative">
          <input
            type="password"
            placeholder="New Password"
            className="w-full h-[63px] border-3 border-bank-primary rounded-[10px] bg-white backdrop-blur-sm px-6 text-xl font-semibold text-[#5E5E5E] placeholder:text-[#5E5E5E] focus:outline-none focus:ring-2 focus:ring-bank-primary"
          />
        </div>

        {/* Phone number input */}
        <div className="relative">
          <input
            type="tel"
            placeholder="Phone Number"
            className="w-full h-[63px] border-3 border-bank-primary rounded-[10px] bg-white backdrop-blur-sm px-6 text-xl font-semibold text-[#5E5E5E] placeholder:text-[#5E5E5E] focus:outline-none focus:ring-2 focus:ring-bank-primary"
          />
        </div>

        {/* NIC Number input */}
        <div className="relative mb-8">
          <input
            type="text"
            placeholder="NIC Number"
            className="w-full h-[63px] border-3 border-bank-primary rounded-[10px] bg-white backdrop-blur-sm px-6 text-xl font-semibold text-[#5E5E5E] placeholder:text-[#5E5E5E] focus:outline-none focus:ring-2 focus:ring-bank-primary"
          />
        </div>

        {/* Create button */}
        <div className="flex justify-center">
          <Link
            to="/pin-auth"
            className="w-[211px] h-16 bg-bank-primary rounded-[10px] flex items-center justify-center"
          >
            <span className="text-white font-segoe text-[32px] font-bold">
              Create
            </span>
          </Link>
        </div>
      </div>
    </div>
  );
}
