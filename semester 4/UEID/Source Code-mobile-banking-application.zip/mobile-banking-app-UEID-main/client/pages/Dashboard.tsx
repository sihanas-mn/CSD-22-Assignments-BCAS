import { Link } from "react-router-dom";
import { Bell } from "lucide-react";

export default function Dashboard() {
  const transactions = [
    {
      description: "Daraz.lk",
      date: "8/1/25",
      amount: "-1,050.00 LKR",
      isNegative: true,
    },
    {
      description: "Ahamed B",
      date: "8/2/25",
      amount: "3,000.00 LKR",
      isNegative: false,
    },
    {
      description: "Company ABZ",
      date: "8/3/25",
      amount: "9,500.00 LKR",
      isNegative: false,
    },
    {
      description: "Airtel.lk",
      date: "8/4/25",
      amount: "-909.00 LKR",
      isNegative: true,
    },
  ];

  return (
    <div className="min-h-screen bg-white font-inter">
      {/* Header */}
      <div className="flex items-center justify-between px-4 pt-5 pb-4">
        <h1 className="text-2xl font-semibold text-black">Hello, Sihanas.</h1>
        <button>
          <img
            src="https://api.builder.io/api/v1/image/assets/TEMP/bab9b500e1e4e309dc23499fb5786701f5d5de58?width=90"
            alt="Notification"
            className="w-[45px] h-[39px]"
          />
        </button>
      </div>

      {/* Dashboard title */}
      <div className="text-center mb-6">
        <h2 className="text-xl font-bold text-bank-success">Dashboard</h2>
        <div className="w-full h-px bg-black mt-2"></div>
      </div>

      {/* Balance card */}
      <div className="mx-9 mb-8 relative">
        <div className="w-full h-[259px] relative rounded-lg overflow-hidden">
          <img
            src="https://api.builder.io/api/v1/image/assets/TEMP/28d0465832391c12fcd2c4ac8dc2cefd919a3bfc?width=732"
            alt="Balance background"
            className="w-full h-full object-cover"
          />

          {/* Balance content overlay */}
          <div className="absolute inset-0 flex flex-col justify-between p-4">
            <div>
              <h3 className="text-2xl font-bold text-white mb-16">Balance</h3>
              <h4 className="text-2xl font-bold text-white mb-4">
                Available Balance
              </h4>
              <p className="text-[32px] font-bold text-white">LKR 153,691.00</p>
            </div>

            <div className="space-y-1">
              <div className="flex justify-between">
                <span className="text-base font-bold text-white">
                  Current Balance
                </span>
                <span className="text-base font-bold text-white">
                  LKR 150,691.00
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-base font-bold text-white">
                  Total Holds
                </span>
                <span className="text-base font-bold text-white">
                  LKR 3,000.00
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Transactions section */}
      <div className="mx-9 mb-20">
        <div className="bg-bank-light rounded-lg p-4">
          {/* Transaction header */}
          <div className="flex justify-between items-center mb-4">
            <span className="text-xl font-medium text-black">Description</span>
            <span className="text-xl font-medium text-black">Amount</span>
          </div>

          <div className="h-px bg-[#727171] mb-4"></div>

          {/* Transaction list */}
          <div className="space-y-4">
            {transactions.map((transaction, index) => (
              <div key={index}>
                <div className="flex justify-between items-start">
                  <div>
                    <p className="text-xl font-semibold text-black">
                      {transaction.description}
                    </p>
                    <p className="text-xl font-normal text-black">
                      {transaction.date}
                    </p>
                  </div>
                  <p
                    className={`text-xl font-semibold ${
                      transaction.isNegative
                        ? "text-red-500"
                        : "text-bank-success"
                    }`}
                  >
                    {transaction.amount}
                  </p>
                </div>
                {index < transactions.length - 1 && (
                  <div className="h-px bg-[#727171] mt-4"></div>
                )}
              </div>
            ))}
          </div>

          {/* View more link */}
          <div className="text-center mt-6">
            <Link to="/transfers" className="text-xl text-bank-secondary">
              Click here to view more &gt;&gt;
            </Link>
          </div>
        </div>
      </div>

      {/* Bottom navigation */}
      <div className="fixed bottom-0 left-0 right-0 bg-bank-nav h-[66px] flex items-center justify-around">
        <Link to="/dashboard" className="flex flex-col items-center">
          <img
            src="https://api.builder.io/api/v1/image/assets/TEMP/f50688b776ad3f418758f1989154fed892ad9602?width=144"
            alt="Home"
            className="w-[72px] h-[42px]"
          />
        </Link>
        <Link to="/transfers" className="flex flex-col items-center">
          <img
            src="https://api.builder.io/api/v1/image/assets/TEMP/9838f49cefae167106bbad8d8e3c9873056fd9c4?width=144"
            alt="Transaction"
            className="w-[72px] h-[42px]"
          />
        </Link>
        <Link to="/profile" className="flex flex-col items-center">
          <img
            src="https://api.builder.io/api/v1/image/assets/TEMP/7b50a5bb28045ff2b5f12ea388eef7542371b9ae?width=144"
            alt="Profile"
            className="w-[72px] h-[42px]"
          />
        </Link>
      </div>
    </div>
  );
}
