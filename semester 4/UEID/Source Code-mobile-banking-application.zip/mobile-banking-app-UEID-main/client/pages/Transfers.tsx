import { Link } from "react-router-dom";

export default function Transfers() {
  return (
    <div className="min-h-screen bg-white font-inter">
      {/* Header */}
      <div className="text-center pt-9 pb-6">
        <h1 className="text-xl font-bold text-bank-success">Transfers</h1>
        <div className="w-full h-px bg-black mt-2"></div>
      </div>

      {/* Transfer options */}
      <div className="px-6 mb-8">
        <div className="flex items-center justify-center gap-4 mb-8">
          {/* Money Transfer */}
          <div className="flex flex-col items-center">
            <Link to="/money-transfer" className="mb-2">
              <img
                src="https://api.builder.io/api/v1/image/assets/TEMP/c68d38def3b8e4ce951779d2fcf6423464dcd7b2?width=200"
                alt="Transfer Money"
                className="w-[100px] h-[100px]"
              />
            </Link>
            <span className="text-xl font-medium text-black">
              Money Transfer
            </span>
          </div>

          {/* Divider */}
          <div className="w-px h-20 bg-black"></div>

          {/* Bill Payment */}
          <div className="flex flex-col items-center">
            <Link to="/bill-payment" className="mb-2">
              <img
                src="https://api.builder.io/api/v1/image/assets/TEMP/902b3f2d9bd3263f5aa8ad6bf08e8dd20a386904?width=200"
                alt="Bill Payment"
                className="w-[100px] h-[100px]"
              />
            </Link>
            <span className="text-xl font-medium text-black">Bill Payment</span>
          </div>
        </div>
      </div>

      {/* Transaction History */}
      <div className="px-6 mb-20">
        <h2 className="text-xl font-medium text-black mb-4">
          Transaction History
        </h2>

        <div className="bg-bank-light rounded-lg p-4 space-y-4">
          {/* Transaction 1 */}
          <div className="bg-white rounded-lg p-4">
            <div className="flex justify-between items-start mb-2">
              <span className="text-xl font-semibold text-black">
                Transfer to Other Bank
              </span>
              <span className="text-xl font-medium text-bank-primary">
                LKR 8,500.00
              </span>
            </div>
            <div className="text-base text-black mb-2">on 8/2/25 4.31 PM</div>
            <div className="h-px bg-[#727171] mb-2"></div>
            <div className="space-y-1 text-lg text-black">
              <div>To Account: 00716545631</div>
              <div>Beneficiary Name: MR M ELON</div>
              <div>From Account: 98465452154</div>
            </div>
          </div>

          {/* Transaction 2 */}
          <div className="bg-white rounded-lg p-4">
            <div className="flex justify-between items-start mb-2">
              <span className="text-xl font-semibold text-black">
                Transfer within Own Acc
              </span>
              <span className="text-xl font-medium text-bank-primary">
                LKR 5,250.00
              </span>
            </div>
            <div className="text-base text-black mb-2">on 7/31/25 2.12 PM</div>
            <div className="h-px bg-[#727171] mb-2"></div>
            <div className="space-y-1 text-lg text-black">
              <div>To Account: 98461227612</div>
              <div>From Account: 98465452154</div>
            </div>
          </div>

          {/* Transaction 3 */}
          <div className="bg-white rounded-lg p-4">
            <div className="flex justify-between items-start mb-2">
              <span className="text-xl font-semibold text-black">
                Bill Payment
              </span>
              <span className="text-xl font-medium text-bank-primary">
                LKR 1,500.00
              </span>
            </div>
            <div className="text-base text-black mb-2">on 8/1/25 7.45 AM</div>
            <div className="h-px bg-[#727171] mb-2"></div>
            <div className="space-y-1 text-lg text-black">
              <div>From Account: 98465452154</div>
              <div>Biller: Dialog Axiata</div>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom navigation */}
      <div className="fixed bottom-0 left-0 right-0 bg-bank-nav h-[66px] flex items-center justify-around">
        <Link to="/dashboard" className="flex flex-col items-center">
          <img
            src="https://api.builder.io/api/v1/image/assets/TEMP/f50688b776ad3f418758f1989154fed892ad9602?width=144"
            alt="Home"
            className="w-[72px] h-[42px]"
          />
        </Link>
        <Link to="/transfers" className="flex flex-col items-center">
          <img
            src="https://api.builder.io/api/v1/image/assets/TEMP/9838f49cefae167106bbad8d8e3c9873056fd9c4?width=144"
            alt="Transaction"
            className="w-[72px] h-[42px]"
          />
        </Link>
        <Link to="/profile" className="flex flex-col items-center">
          <img
            src="https://api.builder.io/api/v1/image/assets/TEMP/7b50a5bb28045ff2b5f12ea388eef7542371b9ae?width=144"
            alt="Profile"
            className="w-[72px] h-[42px]"
          />
        </Link>
      </div>
    </div>
  );
}
