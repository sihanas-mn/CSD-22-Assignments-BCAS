import { Link } from "react-router-dom";
import { useState } from "react";

export default function PinAuth() {
  const [pin, setPin] = useState("");

  const handleNumberClick = (num: string) => {
    if (pin.length < 4) {
      setPin(pin + num);
    }
  };

  const handleClear = () => {
    setPin("");
  };

  const handleFingerprint = () => {
    // Navigate to dashboard
    window.location.href = "/dashboard";
  };

  return (
    <div className="min-h-screen bg-white font-inter relative overflow-hidden">
      {/* Background sky image */}
      <div className="absolute inset-0">
        <img
          src="https://api.builder.io/api/v1/image/assets/TEMP/374f1b0e474a7342e01e97dccde8625158b23125?width=880"
          alt="Sky background"
          className="w-full h-full object-cover opacity-60"
        />
      </div>

      {/* Content overlay */}
      <div className="relative z-10 flex flex-col items-center justify-center min-h-screen px-5">
        {/* Bank name */}
        <div className="text-center mb-16">
          <h1 className="text-[36px] font-bold text-black font-instrument-sans">
            People's Link Bank
          </h1>
        </div>

        {/* Instructions */}
        <div className="text-center mb-12 px-9">
          <p className="text-2xl font-medium text-black leading-normal">
            Please Press the fingerprint sensor or
            <br />
            Enter the PIN Code
          </p>
        </div>

        {/* PIN display line */}
        <div className="w-[337px] h-px bg-black mb-12"></div>

        {/* PIN dots display */}
        <div className="flex justify-center gap-4 mb-8">
          {[0, 1, 2, 3].map((index) => (
            <div
              key={index}
              className={`w-4 h-4 rounded-full border-2 border-black ${
                index < pin.length ? "bg-black" : "bg-transparent"
              }`}
            />
          ))}
        </div>

        {/* Number pad */}
        <div className="grid grid-cols-3 gap-x-16 gap-y-8 mb-16">
          {/* Row 1 */}
          <button
            onClick={() => handleNumberClick("1")}
            className="w-12 h-12 flex items-center justify-center"
          >
            <span className="text-[40px] font-medium text-black">1</span>
          </button>
          <button
            onClick={() => handleNumberClick("2")}
            className="w-12 h-12 flex items-center justify-center"
          >
            <span className="text-[40px] font-medium text-black">2</span>
          </button>
          <button
            onClick={() => handleNumberClick("3")}
            className="w-12 h-12 flex items-center justify-center"
          >
            <span className="text-[40px] font-medium text-black">3</span>
          </button>

          {/* Row 2 */}
          <button
            onClick={() => handleNumberClick("4")}
            className="w-12 h-12 flex items-center justify-center"
          >
            <span className="text-[40px] font-medium text-black">4</span>
          </button>
          <button
            onClick={() => handleNumberClick("5")}
            className="w-12 h-12 flex items-center justify-center"
          >
            <span className="text-[40px] font-medium text-black">5</span>
          </button>
          <button
            onClick={() => handleNumberClick("6")}
            className="w-12 h-12 flex items-center justify-center"
          >
            <span className="text-[40px] font-medium text-black">6</span>
          </button>

          {/* Row 3 */}
          <button
            onClick={() => handleNumberClick("7")}
            className="w-12 h-12 flex items-center justify-center"
          >
            <span className="text-[40px] font-medium text-black">7</span>
          </button>
          <button
            onClick={() => handleNumberClick("8")}
            className="w-12 h-12 flex items-center justify-center"
          >
            <span className="text-[40px] font-medium text-black">8</span>
          </button>
          <button
            onClick={() => handleNumberClick("9")}
            className="w-12 h-12 flex items-center justify-center"
          >
            <span className="text-[40px] font-medium text-black">9</span>
          </button>
        </div>

        {/* Clear button */}
        <div className="absolute top-[359px] right-8">
          <button onClick={handleClear}>
            <img
              src="https://api.builder.io/api/v1/image/assets/TEMP/39f5d4019f1cd92a461eef8e20199cf3c23163d0?width=128"
              alt="Clear"
              className="w-16 h-12"
            />
          </button>
        </div>

        {/* Fingerprint section */}
        <div className="flex flex-col items-center">
          <button onClick={handleFingerprint} className="mb-8">
            <img
              src="https://api.builder.io/api/v1/image/assets/TEMP/07fb89f36d16513eba04de0d5cd5535829402f55?width=200"
              alt="Fingerprint"
              className="w-[100px] h-[100px]"
            />
          </button>
          <p className="text-xl font-medium text-black text-center">
            Press the Fingerprint sensor
          </p>
        </div>

        {/* Auto-navigate when PIN is complete */}
        {pin.length === 4 && (
          <Link to="/dashboard" className="hidden">
            Navigate to Dashboard
          </Link>
        )}
      </div>
    </div>
  );
}
