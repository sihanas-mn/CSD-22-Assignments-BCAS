import { Link, useLocation } from "react-router-dom";
import { useEffect } from "react";

const NotFound = () => {
  const location = useLocation();

  useEffect(() => {
    console.error(
      "404 Error: User attempted to access non-existent route:",
      location.pathname,
    );
  }, [location.pathname]);

  return (
    <div className="min-h-screen flex items-center justify-center bg-white font-inter">
      <div className="text-center px-8">
        <h1 className="text-6xl font-bold text-bank-primary mb-4">404</h1>
        <p className="text-xl text-gray-600 mb-8">
          This page is not available yet
        </p>
        <p className="text-lg text-gray-500 mb-8">
          Continue prompting to have this feature implemented!
        </p>
        <Link
          to="/dashboard"
          className="bg-bank-primary hover:bg-bank-secondary text-white font-bold py-3 px-6 rounded-lg"
        >
          Go to Dashboard
        </Link>
      </div>
    </div>
  );
};

export default NotFound;
