import { Link } from "react-router-dom";
import { useState } from "react";

export default function ChatSupport() {
  const [message, setMessage] = useState("");

  const messages = [
    {
      id: 1,
      text: "Hello!",
      sender: "user",
      time: "10.45",
      avatar:
        "https://api.builder.io/api/v1/image/assets/TEMP/136d0013bd1a79f18413cf66b308abfe9f9dd8f9?width=100",
    },
    {
      id: 2,
      text: "Hi! I'm Alexi, Your virtual assistant. How can I help you today?",
      sender: "bot",
      time: "10.45",
    },
    {
      id: 3,
      text: "I need a live chat support with a customer care agent",
      sender: "user",
      time: "10.46",
      avatar:
        "https://api.builder.io/api/v1/image/assets/TEMP/136d0013bd1a79f18413cf66b308abfe9f9dd8f9?width=100",
    },
    {
      id: 4,
      text: "Hello Sir! I'm Caitlyn Snow, a customer care agent. You are connected with a live chat. How can I help you?",
      sender: "agent",
      time: "10.47",
      avatar:
        "https://api.builder.io/api/v1/image/assets/TEMP/3a89bd64a29340ac84d5baff33dc934cacd4b684?width=120",
    },
  ];

  return (
    <div className="min-h-screen bg-white font-inter flex flex-col">
      {/* Header */}
      <div className="bg-bank-primary h-[82px] flex items-center relative">
        {/* Back button with white background overlay */}
        <div className="absolute left-0 top-4">
          <div className="relative">
            <div className="w-[115px] h-[94px] bg-white absolute -left-3 -top-3"></div>
            <Link to="/profile" className="relative z-10">
              <img
                src="https://api.builder.io/api/v1/image/assets/TEMP/ad33659c33381eac40061641b81f19d65a13ad9f?width=138"
                alt="Back"
                className="w-[69px] h-[53px]"
              />
            </Link>
          </div>
        </div>

        <div className="flex-1 text-center pr-16">
          <h1 className="text-xl font-bold text-white">
            Virtual Assistant and customer support
          </h1>
        </div>
      </div>

      {/* Chat messages */}
      <div className="flex-1 bg-white px-4 py-6 pb-24 overflow-y-auto">
        <div className="space-y-6">
          {messages.map((msg) => (
            <div
              key={msg.id}
              className={`flex ${msg.sender === "user" ? "justify-end" : "justify-start"}`}
            >
              <div
                className={`flex items-end gap-2 max-w-[80%] ${msg.sender === "user" ? "flex-row-reverse" : "flex-row"}`}
              >
                {/* Avatar */}
                {msg.avatar && (
                  <img
                    src={msg.avatar}
                    alt="Avatar"
                    className={`w-[50px] h-[50px] rounded-full flex-shrink-0 ${
                      msg.sender === "user"
                        ? "border-3 border-bank-primary"
                        : ""
                    }`}
                  />
                )}

                {/* Message bubble */}
                <div
                  className={`flex flex-col ${msg.sender === "user" ? "items-end" : "items-start"}`}
                >
                  <div
                    className={`rounded-[10px] px-4 py-3 ${
                      msg.sender === "user"
                        ? "bg-bank-sky text-white"
                        : msg.sender === "agent"
                          ? "bg-bank-green text-black"
                          : "bg-[rgba(197,204,216,0.75)] text-black"
                    }`}
                  >
                    <p
                      className={`text-base font-bold ${msg.sender === "user" ? "text-right" : "text-left"}`}
                    >
                      {msg.text}
                    </p>
                  </div>
                  <span className="text-base text-black mt-1">{msg.time}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Message input area */}
      <div className="bg-white border-t border-black h-[76px] flex items-center px-4 gap-4">
        <input
          type="text"
          placeholder="Type a message"
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          className="flex-1 text-xl font-bold text-[#5E5E5E] placeholder:text-[#5E5E5E] bg-transparent outline-none"
        />

        <button>
          <img
            src="https://api.builder.io/api/v1/image/assets/TEMP/166dab396560d58fd9d3ba2cc073c78aa1a10dc7?width=100"
            alt="Upload"
            className="w-[50px] h-[50px]"
          />
        </button>

        <button>
          <img
            src="https://api.builder.io/api/v1/image/assets/TEMP/818b96c300c3c897992f72a4b33607ca2e439893?width=100"
            alt="Send"
            className="w-[50px] h-[50px]"
          />
        </button>
      </div>
    </div>
  );
}
