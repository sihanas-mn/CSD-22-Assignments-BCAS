import { Link } from "react-router-dom";

export default function Welcome() {
  return (
    <div className="min-h-screen bg-white font-inter relative overflow-hidden">
      {/* Background Images */}
      <div className="absolute inset-0">
        {/* Top bank building image */}
        <img
          src="https://api.builder.io/api/v1/image/assets/TEMP/1af51e2ce286a03eedafbf3de07434a25b18f97b?width=880"
          alt="Bank building"
          className="w-full h-[357px] object-cover"
        />
        {/* Bottom sky/cloud image with opacity */}
        <img
          src="https://api.builder.io/api/v1/image/assets/TEMP/29c9adf75571ad47464a69a65ef950503f92265b?width=880"
          alt="Sky background"
          className="w-full h-[599px] object-cover opacity-60"
        />
      </div>

      {/* Content overlay */}
      <div className="relative z-10 flex flex-col items-center justify-center min-h-screen px-5">
        {/* Main heading */}
        <div className="text-center mb-8 px-5 mt-32">
          <h1 className="text-[32px] font-normal leading-normal text-black mb-2">
            Welcome to
          </h1>
          <h1 className="text-[32px] font-bold leading-normal text-black mb-2">
            People's Link Bank
          </h1>
          <h1 className="text-[32px] font-normal leading-normal text-black">
            Mobile Application
          </h1>
        </div>

        {/* Subtitle */}
        <div className="text-center mb-16 px-5">
          <p className="text-xl font-bold text-black leading-normal">
            Your finances, simple and secure, within your hands.
          </p>
        </div>

        {/* Buttons */}
        <div className="flex flex-col gap-4 w-full max-w-[364px] px-5">
          {/* Login Button */}
          <Link
            to="/login"
            className="w-full h-14 bg-bank-primary rounded-[5px] flex items-center justify-center"
          >
            <span className="text-white font-inter text-2xl font-bold">
              LOGIN
            </span>
          </Link>

          {/* Register Button */}
          <Link
            to="/register"
            className="w-full h-14 bg-white border-4 border-bank-primary rounded-[5px] flex items-center justify-center backdrop-blur-sm"
          >
            <span className="text-[#4B4B4B] font-inter text-2xl font-bold">
              REGISTER
            </span>
          </Link>
        </div>
      </div>
    </div>
  );
}
