import { Link } from "react-router-dom";

export default function Profile() {
  return (
    <div className="min-h-screen bg-white font-inter">
      {/* Back button */}
      <Link to="/dashboard" className="absolute top-5 left-3 z-20">
        <img
          src="https://api.builder.io/api/v1/image/assets/TEMP/5afa2f28df65147856f2e42952a6ea57e57d3616?width=138"
          alt="Back"
          className="w-[69px] h-[53px]"
        />
      </Link>

      {/* Header */}
      <div className="text-center pt-9 pb-6">
        <h1 className="text-xl font-bold text-bank-success">
          Profile and Support
        </h1>
        <div className="w-full h-px bg-black mt-2"></div>
      </div>

      {/* Main content container */}
      <div className="bg-bank-light min-h-[874px] pt-12">
        <div className="bg-white mx-4 rounded-lg p-6 min-h-[820px] relative">
          {/* User name */}
          <div className="text-center mb-4">
            <h2 className="text-[32px] font-bold text-bank-primary">
              MR MN SIHANAS
            </h2>
          </div>

          {/* Last login info */}
          <div className="text-center mb-8">
            <p className="text-lg text-black">
              Last Login on 06/08/2025 16:41:19 (via Mobile)
            </p>
          </div>

          {/* Profile picture */}
          <div className="flex justify-center mb-12">
            <img
              src="https://api.builder.io/api/v1/image/assets/TEMP/86ceffe68d1023b2d97fafba8112218e77934d21?width=280"
              alt="Profile"
              className="w-[140px] h-[140px] rounded-full border-3 border-bank-primary object-cover"
            />
          </div>

          {/* Action buttons */}
          <div className="space-y-4 mb-8">
            <button className="w-full h-16 bg-bank-primary rounded-[10px] flex items-center justify-center">
              <span className="text-white font-segoe text-[32px] font-bold">
                Change Username
              </span>
            </button>

            <button className="w-full h-16 bg-bank-primary rounded-[10px] flex items-center justify-center">
              <span className="text-white font-segoe text-[32px] font-bold">
                Change Password
              </span>
            </button>

            <button className="w-full h-16 bg-bank-primary rounded-[10px] flex items-center justify-center">
              <span className="text-white font-segoe text-[32px] font-bold">
                Add Fingerprint
              </span>
            </button>

            <button className="w-full h-16 bg-bank-primary rounded-[10px] flex items-center justify-center">
              <span className="text-white font-segoe text-[32px] font-bold">
                Manage Devices
              </span>
            </button>

            <Link to="/chat-support">
              <button className="w-full h-16 bg-bank-primary rounded-[10px] flex items-center justify-center">
                <span className="text-white font-segoe text-[32px] font-bold">
                  Chatbot and Help
                </span>
              </button>
            </Link>
          </div>

          {/* Sign out button */}
          <div className="absolute bottom-6 left-6 right-6">
            <Link to="/">
              <button className="w-full h-16 bg-bank-warning rounded-[10px] flex items-center justify-center">
                <span className="text-white font-segoe text-[32px] font-bold">
                  SIGN OUT
                </span>
              </button>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
