import { Link } from "react-router-dom";

export default function MoneyTransfer() {
  return (
    <div className="min-h-screen bg-white font-inter">
      {/* Back button */}
      <Link to="/transfers" className="absolute top-6 left-2 z-20">
        <img
          src="https://api.builder.io/api/v1/image/assets/TEMP/5afa2f28df65147856f2e42952a6ea57e57d3616?width=138"
          alt="Back"
          className="w-[69px] h-[53px]"
        />
      </Link>

      {/* Header */}
      <div className="text-center pt-9 pb-6">
        <h1 className="text-xl font-bold text-bank-success">Money Transfer</h1>
        <div className="w-full h-px bg-black mt-2"></div>
      </div>

      {/* Main content */}
      <div className="bg-bank-light min-h-[874px] pt-12">
        <div className="bg-white mx-4 rounded-lg p-6 min-h-[820px]">
          <div className="text-center py-20">
            <h2 className="text-2xl font-bold text-bank-primary mb-4">
              Money Transfer Feature
            </h2>
            <p className="text-lg text-gray-600 mb-8">
              This feature is coming soon! Complete money transfer functionality
              will be available here.
            </p>
            <Link
              to="/transfers"
              className="bg-bank-primary text-white px-6 py-3 rounded-lg font-semibold"
            >
              Back to Transfers
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
