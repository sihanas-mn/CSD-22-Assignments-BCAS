import { Link } from "react-router-dom";
import { ArrowLeft } from "lucide-react";

export default function Login() {
  return (
    <div className="min-h-screen bg-white font-inter relative">
      {/* Back button */}
      <Link to="/" className="absolute top-4 left-0 z-20">
        <img
          src="https://api.builder.io/api/v1/image/assets/TEMP/5afa2f28df65147856f2e42952a6ea57e57d3616?width=138"
          alt="Back"
          className="w-[69px] h-[53px]"
        />
      </Link>

      {/* Bank building image */}
      <div className="w-[237px] h-[241px] mx-auto mt-[85px] mb-8">
        <img
          src="https://api.builder.io/api/v1/image/assets/TEMP/32efe2fdb5334cf965fca0c1f2d306356b872ad6?width=474"
          alt="Bank building"
          className="w-full h-full object-cover"
        />
      </div>

      {/* Welcome back heading */}
      <div className="text-center mb-12">
        <h1 className="text-[32px] font-semibold text-black">Welcome back!</h1>
      </div>

      {/* Login form */}
      <div className="px-9 flex flex-col gap-4">
        {/* Username input */}
        <div className="relative">
          <input
            type="text"
            placeholder="Enter Your Username"
            className="w-full h-[63px] border-3 border-bank-primary rounded-[10px] bg-white backdrop-blur-sm px-6 text-xl font-semibold text-[#5E5E5E] placeholder:text-[#5E5E5E] focus:outline-none focus:ring-2 focus:ring-bank-primary"
          />
        </div>

        {/* Password input */}
        <div className="relative">
          <input
            type="password"
            placeholder="Enter Your Password"
            className="w-full h-[63px] border-3 border-bank-primary rounded-[10px] bg-white backdrop-blur-sm px-6 text-xl font-semibold text-[#5E5E5E] placeholder:text-[#5E5E5E] focus:outline-none focus:ring-2 focus:ring-bank-primary"
          />
        </div>

        {/* Forgot password link */}
        <div className="text-right mb-8">
          <Link to="/forgot-password" className="text-xl text-bank-secondary">
            forgot password?
          </Link>
        </div>

        {/* Log In button */}
        <div className="flex justify-center mb-12">
          <Link
            to="/pin-auth"
            className="w-[211px] h-16 bg-bank-primary rounded-[10px] flex items-center justify-center"
          >
            <span className="text-white font-segoe text-[32px] font-bold">
              Log In
            </span>
          </Link>
        </div>

        {/* Register link */}
        <div className="text-center">
          <Link to="/register" className="text-xl text-bank-secondary">
            Don't have an account? Register now
          </Link>
        </div>
      </div>
    </div>
  );
}
