import { Link } from "react-router-dom";

export default function ForgotPassword() {
  return (
    <div className="min-h-screen bg-white font-inter">
      {/* Back button */}
      <Link to="/login" className="absolute top-6 left-2 z-20">
        <img
          src="https://api.builder.io/api/v1/image/assets/TEMP/5afa2f28df65147856f2e42952a6ea57e57d3616?width=138"
          alt="Back"
          className="w-[69px] h-[53px]"
        />
      </Link>

      {/* Header */}
      <div className="text-center pt-9 pb-6">
        <h1 className="text-xl font-bold text-bank-primary">Forgot Password</h1>
        <div className="w-full h-px bg-black mt-2"></div>
      </div>

      {/* Main content */}
      <div className="px-9 pt-20">
        <div className="text-center py-20">
          <h2 className="text-2xl font-bold text-bank-primary mb-4">
            Password Recovery
          </h2>
          <p className="text-lg text-gray-600 mb-8">
            This feature is coming soon! Password recovery functionality will be
            available here.
          </p>
          <Link
            to="/login"
            className="bg-bank-primary text-white px-6 py-3 rounded-lg font-semibold"
          >
            Back to Login
          </Link>
        </div>
      </div>
    </div>
  );
}
