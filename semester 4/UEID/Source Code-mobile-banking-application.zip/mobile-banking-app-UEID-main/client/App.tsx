import { BrowserRouter, Routes, Route } from "react-router-dom";
import Welcome from "./pages/Welcome";
import Login from "./pages/Login";
import Register from "./pages/Register";
import PinAuth from "./pages/PinAuth";
import Dashboard from "./pages/Dashboard";
import Transfers from "./pages/Transfers";
import MoneyTransfer from "./pages/MoneyTransfer";
import BillPayment from "./pages/BillPayment";
import Profile from "./pages/Profile";
import ChatSupport from "./pages/ChatSupport";
import ForgotPassword from "./pages/ForgotPassword";
import NotFound from "./pages/NotFound";

function App() {
  return (
    <BrowserRouter>
      <div className="max-w-md mx-auto bg-white min-h-screen">
        <Routes>
          <Route path="/" element={<Welcome />} />
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />
          <Route path="/forgot-password" element={<ForgotPassword />} />
          <Route path="/pin-auth" element={<PinAuth />} />
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/transfers" element={<Transfers />} />
          <Route path="/money-transfer" element={<MoneyTransfer />} />
          <Route path="/bill-payment" element={<BillPayment />} />
          <Route path="/profile" element={<Profile />} />
          <Route path="/chat-support" element={<ChatSupport />} />
          {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
          <Route path="*" element={<NotFound />} />
        </Routes>
      </div>
    </BrowserRouter>
  );
}

export default App;
